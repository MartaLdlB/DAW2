<?php
    echo "Usuario introducido: " . $_POST["usuario"];
    echo "<br>";
    echo "Clave introducida: " . $_POST["pw"];