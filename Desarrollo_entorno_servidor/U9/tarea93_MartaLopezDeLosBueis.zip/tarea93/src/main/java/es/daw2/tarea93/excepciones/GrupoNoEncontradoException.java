package es.daw2.tarea93.excepciones;

public class GrupoNoEncontradoException extends RuntimeException{
    public GrupoNoEncontradoException (){
        super();
    }
}
