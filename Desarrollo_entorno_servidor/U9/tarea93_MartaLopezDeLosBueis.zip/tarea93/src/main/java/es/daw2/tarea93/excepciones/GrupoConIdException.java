package es.daw2.tarea93.excepciones;

public class GrupoConIdException extends RuntimeException{
    public GrupoConIdException(){
        super();
    }
}
