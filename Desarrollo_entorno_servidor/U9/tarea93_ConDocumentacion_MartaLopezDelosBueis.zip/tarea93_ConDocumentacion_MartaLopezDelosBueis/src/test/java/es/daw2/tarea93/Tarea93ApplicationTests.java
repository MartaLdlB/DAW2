package es.daw2.tarea93;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tarea93ApplicationTests {

	@Test
	void contextLoads() {
	}

}
