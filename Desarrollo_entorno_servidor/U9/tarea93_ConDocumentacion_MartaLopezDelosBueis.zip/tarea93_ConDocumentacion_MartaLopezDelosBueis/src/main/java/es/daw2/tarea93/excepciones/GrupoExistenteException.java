package es.daw2.tarea93.excepciones;

public class GrupoExistenteException extends RuntimeException {
    public GrupoExistenteException(){
        super();
    }
}
