package es.daw2.tarea93;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tarea93Application {

	public static void main(String[] args) {
		SpringApplication.run(Tarea93Application.class, args);
	}

}
