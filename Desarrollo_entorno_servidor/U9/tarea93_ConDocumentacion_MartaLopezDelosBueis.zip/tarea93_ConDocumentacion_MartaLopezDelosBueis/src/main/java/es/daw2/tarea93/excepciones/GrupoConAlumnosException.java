package es.daw2.tarea93.excepciones;

public class GrupoConAlumnosException extends RuntimeException {
    public GrupoConAlumnosException(){
        super();
    }
}
