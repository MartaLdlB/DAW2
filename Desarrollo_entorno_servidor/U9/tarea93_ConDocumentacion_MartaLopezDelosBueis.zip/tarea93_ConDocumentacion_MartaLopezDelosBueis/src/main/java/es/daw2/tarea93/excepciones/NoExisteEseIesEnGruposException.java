package es.daw2.tarea93.excepciones;

public class NoExisteEseIesEnGruposException extends RuntimeException {
    public  NoExisteEseIesEnGruposException(){
        super();
    }
}
