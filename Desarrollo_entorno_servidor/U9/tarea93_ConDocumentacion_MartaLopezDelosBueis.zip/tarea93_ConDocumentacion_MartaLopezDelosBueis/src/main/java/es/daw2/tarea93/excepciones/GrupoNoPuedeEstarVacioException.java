package es.daw2.tarea93.excepciones;

public class GrupoNoPuedeEstarVacioException extends RuntimeException {

    public GrupoNoPuedeEstarVacioException(){ //metodo constructor de la clase
        super();
    }

}
