package es.daw2.tarea82;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tarea82ApplicationTests {

	@Test
	void contextLoads() {
	}

}
