package es.daw2.tarea82;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tarea82Application {

	public static void main(String[] args) {
		SpringApplication.run(Tarea82Application.class, args);
	}

}
