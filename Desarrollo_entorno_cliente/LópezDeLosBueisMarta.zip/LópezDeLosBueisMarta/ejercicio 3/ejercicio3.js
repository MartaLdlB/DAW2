let numeroPositivo = parseInt(prompt("Introduce un numero positivo"));

function raizDigital(numeroPositivo){

    let sumaDeNumeros;
    


}