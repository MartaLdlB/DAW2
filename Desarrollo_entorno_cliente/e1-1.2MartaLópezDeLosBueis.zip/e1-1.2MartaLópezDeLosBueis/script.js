//No es necesario añadir la etiqueta script por que ya está puesta en el HTML
alert("¡Bienvenid@ a 2º DAW!");
console.log("IES Arquitecto Ventura Rodríguez")