console.log('OPERADORES ARITMÉTICOS');

console.log('SUMA: 5 + 4.5 = ' + (5 + 4.5); // SUMA. Devuelve 9.5 (Number)
console.log('RESTA: 5 - 4.5 = ' + (5 - 4.5)); // RESTA. Devuelve 0.5 (Number)
console.log('MULTIPLICACIÓN: 5 * 4.5 = ' + (5 * 4.5)); // MULTIPLICACIÓN. Devuelve 22.5 (Number)
console.log('DIVISIÓN: 7 / 3 = ' + (7 / 3)); // DIVISIÓN. Devuelve 2.333333 (Number)
console.log('RESTO: 7 % 3 = ' + (7 % 3)); // RESTO. Devuelve 1 (Number)
console.log('EXPONENTE: 3 ** 2 = ' + (3 ** 2)); // EXPONENTE. Devuelve 9 (Number)