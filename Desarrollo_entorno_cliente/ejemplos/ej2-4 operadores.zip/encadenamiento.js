console.log('OPERADORES DE ENCADENAMIENTO');

let e1 = "Hola, ";
let e2 = "Mundo";
console.log('e1 + e2: 'e1 + e2);
console.log("Adiós, " + "Mundo");