//let myAge = 30
console.log(myAge);