let botonCoche1 = document.getElementById("coche1");
let botonCoche2 = document.getElementById("coche2");
let botonCoche3 = document.getElementById("coche3");

